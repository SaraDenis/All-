/*!
xCharts v0.3.0 Copyright (c) 2012, tenXer, Inc. All Rights Reserved.
@license MIT license. http://github.com/tenXer/xcharts for details
*/

(function () {

var xChart,
  _vis = {},
  _scales = {},
  _visutils = {};
