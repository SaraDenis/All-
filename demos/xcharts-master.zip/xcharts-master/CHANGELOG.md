0.2.0 / 2013-06-28
==================

  * Fix charts interfereing with each other. [gh-32]
  * Prevent pointer events on line fills. [gh-31]
  * Properly test and use D3 v3. [gh-47]
  * Allow sorting x-axis data with `sortX` option method [gh-46]
  * Properly allow 0 values for xMax, xMin, yMax, yMin. [gh-33], [gh-5]

0.1.3 / 2012-12-21
==================

  * Add options to set min/max values for x and y axes [gh-5], [gh-10]

0.1.2 / 2012-12-13
==================

  * Do not convert to date using line + linear x-scale [gh-7]

0.1.1 / 2012-12-06
==================

  * Fix resize handling for multiple graphs [gh-2]

0.1.0 / 2012-12-05
==================

  * Initial Release
